package com.eldroid.news;

public class Headline {
    private String title;

    public Headline(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}