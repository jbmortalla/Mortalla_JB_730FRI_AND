package com.eldroid.news;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class HeadlineListFragment extends Fragment {

    private List<Headline> headlines = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_headline_list, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        RecyclerView recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Example data
        headlines.add(new Headline("Headline 1"));
        headlines.add(new Headline("Headline 2"));
        headlines.add(new Headline("Headline 3"));

        HeadlineAdapter adapter = new HeadlineAdapter(headlines, this::onHeadlineClick);
        recyclerView.setAdapter(adapter);
    }

    private void onHeadlineClick(Headline headline) {
        NewsContentFragment newsContentFragment = new NewsContentFragment();
        Bundle bundle = new Bundle();
        bundle.putString("headline_title", headline.getTitle());
        newsContentFragment.setArguments(bundle);

        FragmentManager fragmentManager = getParentFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        if (getResources().getConfiguration().orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) {
            fragmentTransaction.replace(R.id.newsContentContainer, newsContentFragment, "NEWS_CONTENT_FRAGMENT");
        } else {
            fragmentTransaction.replace(R.id.headlineListContainer, newsContentFragment, "NEWS_CONTENT_FRAGMENT");
            fragmentTransaction.addToBackStack(null); // Add to back stack
        }

        fragmentTransaction.commit();
    }

}
